// ✅ Hide Desktop WhatsApp Button on Mobile
document.addEventListener("DOMContentLoaded", () => {
  const whatsappBtnDesktop = document.getElementById("whatsappBtn");
  if (window.innerWidth > 768 && whatsappBtnDesktop) {
    whatsappBtnDesktop.style.display = "flex"; // or 'block' if needed
  }
});


// ✅ Scroll Confirm Button Into View on Input Focus (Mobile)
const confirmBtn = document.getElementById("confirmOrderBtn");
const modalInputs = document.querySelectorAll(".modal-content input");

modalInputs.forEach(input => {
  input.addEventListener("focus", () => {
    setTimeout(() => {
      confirmBtn?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 300); // slight delay to wait for keyboard to push content
  });
});

// ✅ Show All Products When "All" Button is Clicked
document.addEventListener("DOMContentLoaded", () => {
  const allCategoryButtons = document.querySelectorAll('.category-btn[data-category="all"]');
  const allProducts = document.querySelectorAll('.product-card');
  const noResultsMsg = document.querySelector(".no-results");

  allCategoryButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      allProducts.forEach(product => product.style.display = "flex");
      noResultsMsg.style.display = "none";
    });
  });
});

// ✅ Auto Scroll Category Bar + Manual Touch Override (Mobile)
const catScrollEl = document.querySelector(".cat-scroll");
let autoScrollInterval;
let userTouched = false;

// Function for auto-scrolling the category bar
function autoScrollCategories() {
  if (userTouched || !catScrollEl) return; // Stop if user touched or element not found

  catScrollEl.scrollLeft += 1;
  
  // If it reaches the end, reset to the beginning
  if (catScrollEl.scrollLeft >= catScrollEl.scrollWidth - catScrollEl.clientWidth) {
    catScrollEl.scrollLeft = 0;
  }
}

// Start auto-scroll only on mobile (viewport width <= 768px)
if (window.innerWidth <= 768 && catScrollEl) {
  autoScrollInterval = setInterval(autoScrollCategories, 50); // Adjust speed by changing 50 (ms)

  // Stop auto-scrolling when the user starts interacting (touches) the category scroll
  catScrollEl.addEventListener("touchstart", () => {
    userTouched = true;
    clearInterval(autoScrollInterval); // Stop auto-scrolling
  });

  // Optionally, restart the auto-scrolling after the user finishes touching (e.g., after they stop dragging)
  catScrollEl.addEventListener("touchend", () => {
    userTouched = false;
    autoScrollInterval = setInterval(autoScrollCategories, 50); // Restart auto-scrolling
  });
}