<?php
/**
 * Custom WhatsApp Grocery Shop – Archive Page
 */

defined('ABSPATH') || exit;
get_header(); ?>

<div class="washop-container">

    <!-- 🟢 Header -->
    <header class="washop-header">
    <div class="header-inner">
        <div class="washop-logo-wrap">
    <img src="https://primeflexpk.com/wp-content/uploads/2025/05/logows.gif" alt="WA Shop Logo" class="washop-logo" />
</div>
    </div>
</header>
 <!-- 🔍 Search -->
        <div class="washop-search">
            <input type="text" id="productSearch" placeholder="Search your grocery..." />
        </div>
    <!-- 📂 Mobile Category Scroller -->
<div class="washop-mobile-catbar">
    <?php
    $terms = get_terms('product_cat', ['hide_empty' => false]);
    if (!empty($terms)) {
        echo '<div class="cat-scroll">';
        echo '<button class="mobile-cat-btn category-btn" data-category="all">All</button>';
        foreach ($terms as $term) {
            echo '<button class="mobile-cat-btn category-btn" data-category="' . esc_attr($term->slug) . '">' . esc_html($term->name) . '</button>';
        }

        echo '</div>';
    }
    ?>
</div>

    <!-- 📦 Body -->
    <div class="washop-body">

        <!-- 📚 Sidebar: Categories -->
        <aside class="washop-sidebar">
            <ul>
                <?php
                echo '<li><button class="category-btn" data-category="all">All</button></li>';
                $terms = get_terms('product_cat', ['hide_empty' => false]);
                if (!empty($terms)) {
                    foreach ($terms as $term) {
                        echo '<li><button class="category-btn" data-category="' . esc_attr($term->slug) . '">' . esc_html($term->name) . '</button></li>';
                    }
                }
                ?>
            </ul>
        </aside>

        <!-- 🛒 Product Grid -->
        <main class="washop-products">
            <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); global $product; ?>
                    <div class="product-card" 
                        data-name="<?php echo esc_attr($product->get_name()); ?>" 
                        data-cat="<?php echo esc_attr(wc_get_product_category_list($product->get_id(), ', ', '', '')); ?>">

                        <!-- Product Image -->
                        <div class="product-img">
                            <?php echo $product->get_image(); ?>
                        </div>

                        <!-- Product Info -->
                        <div class="product-details">
                            <h3 class="product-name"><?php echo esc_html($product->get_name()); ?></h3>
                            <p class="product-price"><?php echo wc_price($product->get_price()); ?></p>
                            <div class="qty-wrap">
                                <input type="number" min="1" step="1" value="1" class="qty-input" />
                                <button class="add-btn">ADD</button>
                            </div>
                        </div>

                    </div>
                <?php endwhile; ?>
                <!-- Invisible block to prevent grid collapse -->
                <div class="product-grid-placeholder"></div>
                <!-- ✅ Add Pagination Here -->
                <?php woocommerce_pagination(); ?>
            <?php else : ?>
            <?php endif; ?>
        </main>

    </div>

    <!-- ✅ Floating WhatsApp Button -->
   <button id="whatsappBtn" class="whatsapp-float">
  <img src="https://primeflexpk.com/wp-content/uploads/2025/05/wabutton.png" width="28" height="28" alt="WhatsApp">
  <span class="whatsapp-count">0</span>
</button>

    <!-- 🧾 Modal Popup -->
    <div id="whatsappModal" class="modal-overlay">
        <div class="modal-content">
            <button class="modal-close">✖</button>
            <h3>Enter Delivery Details</h3>
            <input type="text" id="buildingInput" placeholder="Building Name" />
            <input type="text" id="flatInput" placeholder="Flat Number" />
            <button id="confirmOrderBtn">Confirm Order</button>
        </div>
    </div>

</div>
<!-- 📱 Mobile Sticky Footer -->
<div class="washop-mobile-footer">
    <button class="mobile-menu-btn">☰ Menu</button>
    <button id="whatsappBtnMobile" class="mobile-send-btn">
        Send Order <span class="whatsapp-count">0</span>
    </button>
</div>

<!-- 📂 Slide-Out Category Drawer -->
<div class="mobile-cat-drawer" id="mobileDrawer">
    <button class="drawer-close">✖</button>
    <ul>
        <?php
        echo '<li><button class="category-btn" data-category="all">All</button></li>';
        $terms = get_terms('product_cat', ['hide_empty' => false]);
        foreach ($terms as $term) {
            echo '<li><button class="category-btn">' . esc_html($term->name) . '</button></li>';
        }
        ?>
    </ul>
</div>
<div id="toast" class="washop-toast">Please add at least one item.</div>
<?php get_footer(); ?>