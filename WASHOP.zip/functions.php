<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'chld_thm_cfg_locale_css' ) ):
    function chld_thm_cfg_locale_css( $uri ){
        if ( empty( $uri ) && is_rtl() && file_exists( get_template_directory() . '/rtl.css' ) )
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter( 'locale_stylesheet_uri', 'chld_thm_cfg_locale_css' );

// END ENQUEUE PARENT ACTION
// Enqueue Css and JS //
function washop_enqueue_files() {
    // Enqueue the default style.css
    wp_enqueue_style( 'washop-style', get_stylesheet_directory_uri() . '/style.css' );

    // Enqueue custom.css for custom styles
    wp_enqueue_style( 'washop-custom-style', get_stylesheet_directory_uri() . '/custom.css' );

    // Enqueue responsive.css for responsive design styles
    wp_enqueue_style( 'washop-responsive-style', get_stylesheet_directory_uri() . '/responsive.css' );

    // Enqueue the main script.js
    wp_enqueue_script( 'washop-script', get_stylesheet_directory_uri() . '/script.js', [], false, true );

    // Enqueue custom.js for custom JavaScript logic
    wp_enqueue_script( 'washop-custom-script', get_stylesheet_directory_uri() . '/features.js', [], false, true );
}
add_action( 'wp_enqueue_scripts', 'washop_enqueue_files' );


// Remove default WooCommerce "Add to Cart" button from product loop
// and prevent showing "Add to Cart" on single product pages
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);

// Make all products non-purchasable to disable WooCommerce buying process
add_filter('woocommerce_is_purchasable', '__return_false');

// Remove WooCommerce default content wrappers (optional if using your own structure)
remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

// Redirect all single product pages back to the main shop page
add_action('template_redirect', function() {
  if (is_product()) {
    wp_redirect(get_permalink(woocommerce_get_page_id('shop')));
    exit;
  }
});

// Redirect WooCommerce system pages (cart, checkout, my account) to homepage
function washop_disable_wc_pages() {
  if (is_cart() || is_checkout() || is_account_page()) {
    wp_redirect(home_url('/'));
    exit;
  }
}
add_action('template_redirect', 'washop_disable_wc_pages');
//iOs screen prompt to install app //
function ios_pwa_install_banner_in_header() {
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent.toLowerCase());
        const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent.toLowerCase());
        const isInStandalone = window.navigator.standalone === true;

        if (isIos && isSafari && !isInStandalone && !localStorage.getItem('hideIosInstallPrompt')) {
            const banner = document.createElement('div');
            banner.id = 'ios-install-banner';
            banner.innerHTML = `
                <div style="position:fixed;top:20px;right:20px;background:#000;color:#fff;padding:14px 16px;border-radius:8px;font-size:14px;z-index:9999;box-shadow:0 2px 8px rgba(0,0,0,0.3);font-family:sans-serif;">
                    📲 Tap <strong>Share</strong> then <strong>“Add to Home Screen”</strong>
                    <span id="ios-close-banner" style="margin-left:10px;font-weight:bold;cursor:pointer;">✕</span>
                </div>
            `;
            document.body.appendChild(banner);

            document.getElementById('ios-close-banner').addEventListener('click', () => {
                localStorage.setItem('hideIosInstallPrompt', true);
                banner.remove();
            });
        }
    });
    </script>
    <?php
}
add_action('wp_head', 'ios_pwa_install_banner_in_header');
// Install App Prompt for Android //
function force_android_pwa_prompt() {
    ?>
    <script>
    let deferredPrompt;

    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;

        // Check if banner already exists
        if (document.getElementById('android-install-banner')) return;

        const banner = document.createElement('div');
        banner.id = 'android-install-banner';
        banner.innerHTML = `
            <div style="position:fixed;top:20px;right:-320px;background:#000;color:#fff;padding:12px 20px;border-radius:8px 0 0 8px;font-size:15px;z-index:9999;display:flex;align-items:center;gap:14px;transition:right 0.4s ease-in-out;">
                <span>🧺 Install App</span>
                <button id="install-now" style="background:#00c26d;border:none;color:#fff;padding:8px 14px;border-radius:4px;cursor:pointer;">Install</button>
                <span id="close-banner" style="cursor:pointer;color:#aaa;">✕</span>
            </div>
        `;
        document.body.appendChild(banner);

        setTimeout(() => {
            banner.firstElementChild.style.right = '0';
        }, 300);

        document.getElementById('install-now').addEventListener('click', () => {
            deferredPrompt.prompt();
            banner.remove();
        });

        document.getElementById('close-banner').addEventListener('click', () => {
            localStorage.setItem('hideAndroidInstallPrompt', '1');
            banner.remove();
        });
    });
    </script>
    <?php
}
add_action('wp_footer', 'force_android_pwa_prompt');
