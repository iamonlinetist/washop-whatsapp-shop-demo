document.addEventListener("DOMContentLoaded", function () {
    // 🔍 Search + No Results
    const searchInput = document.getElementById("productSearch");
    const productCards = document.querySelectorAll(".product-card");
    const productContainer = document.querySelector(".washop-products");

    if (!productContainer) {
        console.warn("No .washop-products found!");
        return;
    }

    const noResultsMessage = document.createElement("p");
    noResultsMessage.textContent = "🚫 No products found.";
    noResultsMessage.className = "no-results-message";
    noResultsMessage.style.display = "none";
    productContainer.appendChild(noResultsMessage);

    searchInput?.addEventListener("input", function () {
        const term = this.value.toLowerCase();
        let anyVisible = false;

        productCards.forEach(card => {
            const name = card.dataset.name.toLowerCase();
            const match = name.includes(term);
            card.style.display = match ? "flex" : "none";
            if (match) anyVisible = true;
        });

        noResultsMessage.style.display = anyVisible ? "none" : "block";
    });

    // ✅ WhatsApp / Modal / Toast / Drawer
    const whatsappBtnDesktop = document.getElementById("whatsappBtn");
    const whatsappBtnMobile = document.getElementById("whatsappBtnMobile");
    const whatsappCountEls = document.querySelectorAll(".whatsapp-count");
    const modal = document.getElementById("whatsappModal");
    const confirmOrderBtn = document.getElementById("confirmOrderBtn");
    const buildingInput = document.getElementById("buildingInput");
    const flatInput = document.getElementById("flatInput");
    const modalOverlay = document.querySelector(".modal-overlay");
    const modalClose = document.querySelector(".modal-close");
    const drawer = document.getElementById("mobileDrawer");

    const toast = document.createElement("div");
    toast.id = "toast";
    toast.className = "washop-toast";
    toast.style.display = "none";
    document.body.appendChild(toast);

    function showToast(message, type = "success") {
        toast.textContent = message;
        toast.style.backgroundColor = type === "success" ? "#00c26d" : "#ff4444";
        toast.style.display = "block";
        setTimeout(() => {
            toast.style.display = "none";
        }, 1000);
    }
    
    // 🟢 Category Filtering (Sidebar + Drawer)
    document.querySelectorAll('.category-btn').forEach(button => {
    button.addEventListener('click', () => {
        const selectedCat = button.dataset.category?.toLowerCase() || button.textContent.toLowerCase();

        // Remove 'active' from all category buttons (sidebar + drawer)
        document.querySelectorAll('.category-btn').forEach(btn => {
            btn.classList.remove('active-cat');
        });

        // Add 'active' to clicked button
        button.classList.add('active-cat');

        // Show/hide products
        document.querySelectorAll('.product-card').forEach(card => {
            const productCats = card.dataset.cat.toLowerCase();
            if (productCats.includes(selectedCat)) {
                card.style.display = 'flex';
            } else {
                card.style.display = 'none';
            }
        });

        // Auto-close mobile drawer on selection
        if (window.innerWidth <= 768) {
            drawer?.classList.remove('open');
        }
    });
});

    let cart = [];

    // 🔍 Search filter
    searchInput?.addEventListener("input", function () {
    const term = this.value.toLowerCase();
    let anyVisible = false;

    productCards.forEach(card => {
        const name = card.dataset.name.toLowerCase();
        const match = name.includes(term);
        card.style.display = match ? "flex" : "none";
        if (match) anyVisible = true;
    });

    noResultsMessage.style.display = anyVisible ? "none" : "block";
});

    // ➕ Quantity & Add/Remove Toggle
productCards.forEach(card => {
    const addBtn = card.querySelector(".add-btn");
    const qtyInput = card.querySelector(".qty-input");
    const name = card.dataset.name;

    const wrap = document.createElement("div");
    wrap.className = "qty-controls";
    const minus = document.createElement("button");
    minus.textContent = "−";
    minus.className = "qty-btn";
    const plus = document.createElement("button");
    plus.textContent = "+";
    plus.className = "qty-btn";

    qtyInput.parentNode.insertBefore(wrap, qtyInput);
    wrap.appendChild(minus);
    wrap.appendChild(qtyInput);
    wrap.appendChild(plus);

    // Quantity Controls
    minus.addEventListener("click", () => {
        let val = parseFloat(qtyInput.value) || 1;
        if (val > 1) qtyInput.value = parseInt(val - 1);
    });

    plus.addEventListener("click", () => {
        let val = parseFloat(qtyInput.value) || 1;
        qtyInput.value = parseInt(val + 1);
    });

    // ✅ Add / Remove Toggle
    addBtn.addEventListener("click", () => {
        const existing = cart.find(item => item.name === name);

        if (existing) {
            // Remove from cart
            cart = cart.filter(item => item.name !== name);
            addBtn.textContent = "ADD";
            addBtn.classList.remove("added");
            addBtn.disabled = false;

            showToast("Item removed from cart", "error");
        } else {
            // Add to cart
            const qty = parseFloat(qtyInput.value) || 1;
            cart.push({ name, qty });

            addBtn.textContent = "✓ Remove";
            addBtn.classList.add("added");

            showToast("Item added to cart", "success");
        }

        // Update cart count
        whatsappCountEls.forEach(el => {
            el.textContent = cart.length;
        });
    });
});

    // 🟢 Open Modal
    function openModal() {
        if (cart.length === 0) {
            showToast("Please add at least one item.","error");
            return;
        }
        modal.style.display = "flex";
    }

    whatsappBtnDesktop?.addEventListener("click", openModal);
    whatsappBtnMobile?.addEventListener("click", openModal);

    // ❌ Close Modal
    // Close on overlay click
modalOverlay?.addEventListener("click", (e) => {
    if (e.target === modalOverlay) {
        modal.style.display = "none";
    }
});

// Close on ✖ button click
modalClose?.addEventListener("click", () => {
    modal.style.display = "none";
});


    // ✅ Confirm Order
    confirmOrderBtn?.addEventListener("click", () => {
    const building = buildingInput.value.trim();
    const flat = flatInput.value.trim();

    if (!building || !flat) {
        alert("Please enter both building and flat number.");
        return;
    }

    let message = `🛒 *Order From ${building}* Hey Can you deliver these?\n`;

    cart.forEach((item, index) => {
        message += `${index + 1}. ${item.name} --- ${parseInt(item.qty)}\n`;
    });

    message += `\n🏢 Building: ${building}\n🏠 Flat: ${flat}`;

    const phone = "971561375072";
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");

    modal.style.display = "none";
});


    // 📱 Mobile Menu Drawer
    document.querySelector(".mobile-menu-btn")?.addEventListener("click", () => {
        drawer?.classList.add("open");
    });
    document.querySelector(".drawer-close")?.addEventListener("click", () => {
        drawer?.classList.remove("open");
    });
});